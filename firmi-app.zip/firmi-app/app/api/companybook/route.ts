export async function POST(request:Request){
 const json=(data:object,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
 try{const parsed=await request.json();if(!parsed||typeof parsed!=='object')return json({error:'Невалидна заявка.'},400);const b=parsed as Record<string,unknown>;if(typeof b.key!=='string'||!b.key.trim())return json({error:'Липсва API ключ.'},400);let path:string;
 if(b.action==='search'){if(typeof b.query!=='string'||b.query.trim().length<3||b.query.length>200)return json({error:'Въведи между 3 и 200 символа.'},400);const q=b.query.trim();const p=new URLSearchParams({limit:'20',offset:'0'});p.set(/^(BG)?\d{9,13}$/i.test(q)?'uic':'name',q.replace(/^BG(?=\d)/i,''));path='/api/v2/companies/search?'+p}
 else if(b.action==='detail'&&typeof b.uic==='string'&&/^(BG)?\d{9,13}$/i.test(b.uic))path='/api/companies/'+encodeURIComponent(b.uic)+'?with_data=true';else return json({error:'Невалидна заявка.'},400);
 const r=await fetch('https://api.companybook.bg'+path,{headers:{'X-API-Key':b.key.trim(),Accept:'application/json'},signal:AbortSignal.timeout(15000),redirect:'error'});
 if(!r.ok){const messages:Record<number,string>={400:'Невалидни параметри.',401:'API ключът е невалиден.',403:'Ключът няма достъп до тази справка.',404:'Фирмата не е намерена.',429:'Достигнат е лимитът за заявки. Опитай по-късно.'};return json({error:messages[r.status]||'TheCompanyBook временно не отговаря.'},r.status)}return json(await r.json());
 }catch{return json({error:'Няма връзка с TheCompanyBook или заявката е невалидна. Опитай отново.'},502)}
}
